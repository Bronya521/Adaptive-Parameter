import numpy as np
from EA_toolbox import *


class APSO:
    def __init__(self, func, init_function, dim, size, iter_num, lb, ub, is_print, H):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.H = H

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.v = np.random.rand(self.size, self.dim)
        self.all_points_local = [self.X[i].copy() for i in range(self.size)]
        self.mean_points_local = [np.mean(self.X, axis=0)]

        self.factor = None
        self.M_factor = np.ones((3, self.H), dtype=np.float64)
        self.M_factor[0, :] = self.M_factor[0, :] * 0.7
        self.M_factor[1, :] = self.M_factor[1, :] * 2.0
        self.M_factor[2, :] = self.M_factor[2, :] * 2.0
        self.k = 0
        self.r = 0
        self.Set_success_factor = []

    def updata_M_factor(self):
        if len(self.Set_success_factor) != 0:
            self.Set_success_factor = np.array(self.Set_success_factor)
            new_M_factor = (
                len(self.Set_success_factor)
                / self.size
                * np.array(
                    [lehmer_mean(self.Set_success_factor[:, i], 2) for i in range(3)]
                )
                + (1 - len(self.Set_success_factor) / self.size)
                * self.M_factor[:, self.r]
            )
            self.M_factor[:, self.k] = np.clip(new_M_factor, 0.1, 3.5)

            self.k += 1
            if self.k >= self.H:
                self.k = 0

            self.Set_success_factor = []

    def calculate_factor(self):
        # ���ѡȡһ��Ma��Ϊ����
        self.r = np.random.choice(self.H)
        # ��̬�ֲ�
        self.factor = np.array(
            [
                np.random.normal(loc=ai, scale=0.5, size=self.size)
                for ai in self.M_factor[:, self.r]
            ]
        ).T
        self.factor = np.clip(self.factor, 0.1, 3.5)

    def optimize(self):
        for t in range(self.iter_num):
            self.calculate_factor()
            # ���ӽ����˶�
            for i in range(self.size):
                self.v[i] = (
                    self.factor[i, 0] * self.v[i]
                    + self.factor[i, 1] * np.random.rand() * (self.P[i] - self.X[i])
                    + self.factor[i, 2] * np.random.rand() * (self.gbest - self.X[i])
                )
                self.X[i] = self.X[i] + self.v[i]
                # ���½������ڷ�Χ��
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                self.X_score[i] = self.func(self.X[i])
                self.all_points_local.append(self.X[i].copy())

            for i in range(self.size):
                if self.X_score[i] < self.P_score[i]:
                    self.Set_success_factor.append(self.factor[i])
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i]

            self.updata_M_factor()
            best_index = np.argmin(self.P_score)
            self.gbest = self.P[best_index].copy()
            self.gbest_score = self.P_score[best_index]
            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(
                    f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]},factor:{np.mean(self.factor,axis=0)}"
                )
            self.mean_points_local.append(np.mean(self.X, axis=0))

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
            (self.all_points_local, self.mean_points_local),
        )
