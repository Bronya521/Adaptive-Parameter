import os
import numpy as np
from EA_toolbox import *
import matplotlib.pyplot as plt


class AQPSO:

    def __init__(self, func, init_function, dim, size, iter_num, lb, ub, is_print, H):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.H = H

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.all_points_local = [self.X[i].copy() for i in range(self.size)]
        self.mean_points_local = [np.mean(self.X, axis=0)]

        self.a = None
        self.M_a = np.array([0.5 for _ in range(self.H)])
        self.k = 0
        self.r = 0
        self.Set_success_a = []

    def updata_pop_restore_a(self, i, new_X, new_score):
        self.X[i] = new_X.copy()
        self.X_score[i] = new_score.copy()
        self.all_points_local.append(self.X[i].copy())
        # 更新个体最优
        if self.X_score[i] < self.P_score[i]:
            # 存储成功的a及其权重
            self.Set_success_a.append(self.a[i])
            # 更新个体最优
            self.P[i] = self.X[i].copy()
            self.P_score[i] = self.X_score[i].copy()
            # 更新全局最优
            if self.P_score[i] < self.gbest_score:
                self.gbest = self.P[i].copy()
                self.gbest_score = self.P_score[i].copy()

    def updata_Ma_list(self):
        if len(self.Set_success_a) != 0:
            new_M_a = (
                len(self.Set_success_a) / self.size * lehmer_mean(self.Set_success_a, 2)
                + (1 - len(self.Set_success_a) / self.size) * self.M_a[self.r]
            )
            self.M_a[self.k] = np.clip(
                new_M_a,
                0.3,
                1.78,
            )

            self.k += 1
            if self.k >= self.H:
                self.k = 0

            self.Set_success_a = []

    def calculate_a(self):
        # 随机选取一个Ma作为期望
        self.r = np.random.choice(self.H)
        # 正态分布
        self.a = np.random.normal(loc=self.M_a[self.r], scale=0.1, size=self.size)
        self.a = np.clip(self.a, 0.1, 1.78)

    def get_p(self, i, t):
        center = self.a[i]
        random_factor = np.random.normal(
            loc=center,
            scale=((0.05 - 0.5) / self.iter_num * t + 0.5),
            size=self.dim,
        )
        p = (1 - random_factor) * self.P[i] + random_factor * self.gbest
        return p

    def optimize(self):
        for t in range(self.iter_num):
            # 个体历史最优均值
            average_p = np.sum(self.P, axis=0) / self.size
            # 计算收缩膨胀因子a
            self.calculate_a()
            # 粒子进行运动
            for i in range(self.size):
                # 计算吸引子位置
                p = self.get_p(i, t)
                random_factor_log = np.random.rand(self.dim)
                random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
                new_X = p + np.sign(random_factor_sign) * self.a[i] * np.abs(
                    average_p - self.X[i]
                ) * np.log(random_factor_log)
                # 将新解限制在范围内
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)
                # 更新当前种群和存储成功的a
                self.updata_pop_restore_a(i, new_X, new_score)

            # 调整Ma列表
            self.updata_Ma_list()

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(
                    f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}, a:{np.mean(self.a)}"
                )
            self.mean_points_local.append(np.mean(self.X, axis=0))

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
            (self.all_points_local, self.mean_points_local),
        )

    def plot_best(self, title, save_path):
        plt.plot(self.gbest_scores)
        plt.yscale("log")  # 设置纵轴为对数尺度
        plt.xlabel("Iteration", fontsize=16)
        plt.ylabel("Fitness", fontsize=16)
        plt.title("Optimization curve", fontsize=16)

        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")

        plt.show()
