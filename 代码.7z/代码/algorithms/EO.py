import numpy as np
from EA_toolbox import *
import matplotlib.pyplot as plt


class EO:
    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, is_print, a_1, a_2
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.a_1 = a_1
        self.a_2 = a_2

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.X_pool = self.X[np.argsort(self.X_score)[:4]].copy()
        self.X_pool = np.vstack([self.X_pool, np.mean(self.X_pool, axis=0)]).copy()
        self.X_pool_score = np.array(
            [self.func(self.X_pool[i]) for i in range(len(self.X_pool))]
        )
        self.all_points_local = [self.X[i].copy() for i in range(self.size)]
        self.mean_points_local = [np.mean(self.X, axis=0)]

        self.history_F = []

    def update_X_pool(self):
        pool = np.vstack([self.X_pool[:-1], self.X]).copy()
        pool_score = np.concatenate((self.X_pool_score[:-1], self.X_score))
        pool_index = np.argsort(pool_score)[:4]

        self.X_pool[:-1] = pool[pool_index].copy()
        self.X_pool[-1] = np.mean(self.X_pool[:-1], axis=0).copy()
        self.X_pool_score[:-1] = pool_score[pool_index]
        self.X_pool_score[-1] = self.func(self.X_pool[-1])

    def optimize(self):
        for t in range(self.iter_num):
            t_factor = (1 - t / self.iter_num) ** (self.a_2 * t / self.iter_num)
            # ���ӽ����˶�
            for i in range(self.size):
                random_X_pool = self.X_pool[np.random.choice(len(self.X_pool))].copy()
                lambda_random = np.random.rand(self.dim)
                F = (
                    self.a_1
                    * np.sign(np.random.rand(self.dim) - 0.5)
                    * (np.exp(-lambda_random * t_factor) - 1)
                )
                self.history_F.append(F[0])
                if np.random.rand() < 0.5:
                    random_num = 0
                else:
                    random_num = 0.5 * np.random.rand()
                G = (
                    np.ones_like(F)
                    * random_num
                    * (random_X_pool - lambda_random * self.X[i])
                    * F
                )
                self.X[i] = (
                    random_X_pool
                    + (self.X[i] - random_X_pool) * F
                    + G / lambda_random * (1 - F)
                )
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                self.X_score[i] = self.func(self.X[i])
                self.all_points_local.append(self.X[i].copy())

            self.update_X_pool()
            gbest_score_index = np.argmin(self.X_pool_score)
            if self.X_pool_score[gbest_score_index] < self.gbest_score:
                self.gbest_score = self.X_pool_score[gbest_score_index]
                self.gbest = self.X_pool[gbest_score_index].copy()
            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")
            self.mean_points_local.append(np.mean(self.X, axis=0))

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
            (self.all_points_local, self.mean_points_local),
        )

    def plot_F(self):
        plt.plot(self.history_F)
        plt.show()
