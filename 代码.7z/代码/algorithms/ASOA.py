import numpy as np
from EA_toolbox import *


class ASOA:
    def __init__(self, func, init_function, dim, size, iter_num, lb, ub, is_print, H):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.H = H

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.A = None
        self.M_A = np.array([2.0 for _ in range(self.H)])
        self.k = 0
        self.r = 0
        self.Set_success_A = []
        self.history_A = []

    def updata_Ma_list(self):
        if len(self.Set_success_A) != 0:
            new_M_A = (
                len(self.Set_success_A) / self.size * lehmer_mean(self.Set_success_A, 1.5)
                + (1 - len(self.Set_success_A) / self.size) * self.M_A[self.r]
            )
            self.M_A[self.k] = np.clip(new_M_A, 0.0, 2.0)

            self.k += 1
            if self.k >= self.H:
                self.k = 0

            self.Set_success_A = []

    def calculate_A(self):
        # ���ѡȡһ��Ma��Ϊ����
        self.r = np.random.choice(self.H)
        # ��̬�ֲ�
        self.A = np.random.normal(loc=self.M_A[self.r], scale=0.3, size=self.size)
        self.A = np.clip(self.A, 0.0, 2.0)

    def optimize(self):
        for t in range(self.iter_num):
            self.calculate_A()
            for i in range(self.size):
                C_s = self.A[i] * self.X[i]
                B = 2 * self.A[i] ** 2 * np.random.rand()
                M_s = B * (self.gbest - self.X[i])
                D_s = np.abs(C_s + M_s)
                k = np.random.rand() * 2 * np.pi
                r = np.exp(k)
                x, y, z = r * np.cos(k), r * np.sin(k), r * k
                self.X[i] = D_s * x * y * z + self.gbest
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                old_score = self.X_score[i]
                self.X_score[i] = self.func(self.X[i])
                if self.X_score[i] < old_score:
                    self.Set_success_A.append(self.A[i])
            self.updata_Ma_list()
            best_index = np.argmin(self.X_score)
            if self.X_score[best_index] < self.gbest_score:
                self.gbest = self.X[best_index].copy()
                self.gbest_score = self.X_score[best_index]
            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(
                    f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}, A:{np.mean(self.A)}"
                )

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )
