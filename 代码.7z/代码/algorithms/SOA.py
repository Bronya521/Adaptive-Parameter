import numpy as np
from EA_toolbox import *


class SOA:
    def __init__(self, func, init_function, dim, size, iter_num, lb, ub, is_print, f_c):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.f_c = f_c

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

    def optimize(self):
        for t in range(self.iter_num):
            A = self.f_c - (t / self.iter_num * self.f_c)
            for i in range(self.size):
                C_s = A * self.X[i]
                B = 2 * A**2 * np.random.rand()
                M_s = B * (self.gbest - self.X[i])
                D_s = np.abs(C_s + M_s)
                k = np.random.rand() * 2 * np.pi
                r = np.exp(k)
                x, y, z = r * np.cos(k), r * np.sin(k), r * k
                self.X[i] = D_s * x * y * z + self.gbest
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                self.X_score[i] = self.func(self.X[i])
            best_index = np.argmin(self.X_score)
            if self.X_score[best_index] < self.gbest_score:
                self.gbest = self.X[best_index].copy()
                self.gbest_score = self.X_score[best_index].copy()
            self.gbest_scores.append(self.gbest_score)

            if self.is_print:
                print(
                    f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}"
                )

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )
