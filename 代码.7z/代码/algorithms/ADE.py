import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *


class ADE:
    def __init__(self, func, init_function, dim, size, iter_num, lb, ub, is_print, H):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.H = H

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.all_points_local = [self.X[i].copy() for i in range(self.size)]
        self.mean_points_local = [np.mean(self.X, axis=0)]

        self.factor = None
        self.M_factor = np.ones((2, self.H), dtype=np.float64)
        self.M_factor[0, :] = self.M_factor[0, :] * 0.5
        self.M_factor[1, :] = self.M_factor[1, :] * 0.5
        self.k = 0
        self.r = 0
        self.Set_success_factor = []

    def updata_M_factor(self):
        if len(self.Set_success_factor) != 0:
            self.Set_success_factor = np.array(self.Set_success_factor)
            new_M_factor = (
                len(self.Set_success_factor)
                / self.size
                * np.array(
                    [lehmer_mean(self.Set_success_factor[:, i], 2) for i in range(2)]
                )
                + (1 - len(self.Set_success_factor) / self.size)
                * self.M_factor[:, self.r]
            )
            self.M_factor[:, self.k] = np.clip(new_M_factor, 0.1, 1)

            self.k += 1
            if self.k >= self.H:
                self.k = 0

            self.Set_success_factor = []

    def calculate_factor(self):
        # ���ѡȡһ��Ma��Ϊ����
        self.r = np.random.choice(self.H)
        # ��̬�ֲ�
        self.factor = np.array(
            [
                np.random.normal(loc=ai, scale=0.1, size=self.size)
                for ai in self.M_factor[:, self.r]
            ]
        ).T
        self.factor = np.clip(self.factor, 0.1, 1)

    def optimize(self):
        for t in range(self.iter_num):
            self.calculate_factor()
            for j in range(self.size):
                idxs = [idx for idx in range(self.size) if idx != j]
                a, b, c = self.X[np.random.choice(idxs, 3, replace=False)].copy()
                mutant = np.clip(a + self.factor[j, 0] * (b - c), self.lb, self.ub)
                cross_points = np.random.rand(self.dim) < self.factor[j, 1]
                if not np.any(cross_points):
                    cross_points[np.random.randint(0, self.dim)] = True
                trial = np.where(cross_points, mutant, self.X[j])
                score_trial = self.func(trial)
                self.all_points_local.append(trial.copy())
                if score_trial < self.X_score[j]:
                    self.Set_success_factor.append(self.factor[j])
                    self.X_score[j] = score_trial
                    self.X[j] = trial.copy()
                    if score_trial < self.gbest_score:
                        self.gbest = self.X[j].copy()
                        self.gbest_score = score_trial
            self.gbest_scores.append(self.gbest_score)
            self.updata_M_factor()
            if self.is_print:
                print(
                    f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]},factor:{np.mean(self.factor,axis=0)}"
                )
            self.mean_points_local.append(np.mean(self.X, axis=0))

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
            (self.all_points_local, self.mean_points_local),
        )

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("DE Optimization Process")
        plt.show()
