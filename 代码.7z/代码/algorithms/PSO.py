import numpy as np
from EA_toolbox import *


class PSO:
    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, is_print, w, c_1, c_2
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.w = w
        self.c_1 = c_1
        self.c_2 = c_2

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.v = np.random.rand(self.size, self.dim)
        self.all_points_local = [self.X[i].copy() for i in range(self.size)]
        self.mean_points_local = [np.mean(self.X, axis=0)]

    def optimize(self):
        for t in range(self.iter_num):
            # ���ӽ����˶�
            for i in range(self.size):
                self.v[i] = (
                    self.w * self.v[i]
                    + self.c_1 * np.random.rand() * (self.P[i] - self.X[i])
                    + self.c_2 * np.random.rand() * (self.gbest - self.X[i])
                )
                self.X[i] = self.X[i] + self.v[i]
                # ���½������ڷ�Χ��
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                self.X_score[i] = self.func(self.X[i])
                self.all_points_local.append(self.X[i].copy())

            for i in range(self.size):
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i]
            best_index = np.argmin(self.P_score)
            self.gbest = self.P[best_index].copy()
            self.gbest_score = self.P_score[best_index]
            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")
            self.mean_points_local.append(np.mean(self.X, axis=0))

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
            (self.all_points_local, self.mean_points_local),
        )
