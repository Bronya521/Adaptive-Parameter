import matplotlib.pyplot as plt
import numpy as np
from EA_toolbox import *


class AEO:
    def __init__(self, func, init_function, dim, size, iter_num, lb, ub, is_print, H):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.H = H

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.X_pool = self.X[np.argsort(self.X_score)[:4]]
        self.X_pool = np.vstack([self.X_pool, np.mean(self.X_pool, axis=0)])
        self.X_pool_score = np.array(
            [self.func(self.X_pool[i]) for i in range(len(self.X_pool))]
        )
        self.all_points_local = [self.X[i].copy() for i in range(self.size)]
        self.mean_points_local = [np.mean(self.X, axis=0)]

        self.F = None
        self.M_F = np.array([1.3 for _ in range(self.H)])
        self.k = 0
        self.r = 0
        self.Set_success_F = []
        self.history_F = []

    def updata_Ma_list(self):
        if len(self.Set_success_F) != 0:
            new_M_F = (
                len(self.Set_success_F) / self.size * lehmer_mean(self.Set_success_F, 1)
                + (1 - len(self.Set_success_F) / self.size) * self.M_F[self.r]
            )
            self.M_F[self.k] = np.clip(
                new_M_F,
                0.0,
                1.3,
            )

            self.k += 1
            if self.k >= self.H:
                self.k = 0

            self.Set_success_F = []

    def calculate_F(self):
        # ���ѡȡһ��Ma��Ϊ����
        self.r = np.random.choice(self.H)
        # ��̬�ֲ�
        self.F = np.random.normal(loc=self.M_F[self.r], scale=0.3, size=self.size)
        self.F = np.clip(self.F, 0.0, 1.3)

    def update_X_pool(self):
        pool = np.vstack([self.X_pool[:-1], self.X]).copy()
        pool_score = np.concatenate((self.X_pool_score[:-1], self.X_score))
        pool_index = np.argsort(pool_score)[:4]

        self.X_pool[:-1] = pool[pool_index].copy()
        self.X_pool[-1] = np.mean(self.X_pool[:-1], axis=0).copy()
        self.X_pool_score[:-1] = pool_score[pool_index]
        self.X_pool_score[-1] = self.func(self.X_pool[-1])

    def optimize(self):
        for t in range(self.iter_num):
            self.calculate_F()
            # ���ӽ����˶�
            for i in range(self.size):
                random_X_pool = self.X_pool[np.random.choice(len(self.X_pool))].copy()
                lambda_random = np.random.rand(self.dim)
                F = np.random.normal(loc=self.F[i], scale=0.1, size=self.dim) * np.sign(
                    np.random.uniform(-1, 1, self.dim)
                )
                if np.random.rand() < 0.5:
                    random_num = 0
                else:
                    random_num = 0.5 * np.random.rand()
                G = (
                    np.ones_like(F)
                    * random_num
                    * (random_X_pool - lambda_random * self.X[i])
                    * F
                )
                self.X[i] = (
                    random_X_pool
                    + (self.X[i] - self.X[np.random.choice(self.size)])
                    * F
                    * (np.random.rand(self.dim) - 0.5)
                    + G / lambda_random * (1 - F)
                )
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                self.all_points_local.append(self.X[i].copy())
                old_score = self.X_score[i]
                self.X_score[i] = self.func(self.X[i])
                if self.X_score[i] < old_score:
                    self.Set_success_F.append(self.F[i])

            self.update_X_pool()
            self.updata_Ma_list()
            gbest_score_index = np.argmin(self.X_pool_score)
            if self.X_pool_score[gbest_score_index] < self.gbest_score:
                self.gbest_score = self.X_pool_score[gbest_score_index]
                self.gbest = self.X_pool[gbest_score_index].copy()
            self.gbest_scores.append(self.gbest_score)
            self.history_F.append(np.mean(self.F))
            if self.is_print:
                print(
                    f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}, F:{np.mean(self.F)}"
                )
            self.mean_points_local.append(np.mean(self.X, axis=0))

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
            (self.all_points_local, self.mean_points_local),
        )

    def plot_F(self):
        plt.plot(self.history_F)
        plt.show()
