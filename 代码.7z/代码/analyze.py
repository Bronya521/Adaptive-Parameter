import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np
from Data import *
from testMain_base import get_parameter
from algorithms import *
from EA_toolbox import *
import seaborn as sns

function_names = [
    Sphere,
    Rosenbrock,
    Schwefel_222,
    Schwefel_12,
    Schwefel_221,
    Schwefel_226,
    Rastrigin,
    Ackley,
    Griewank,
    Penalized1,
    Penalized2,
    F12,
    F13,
    F14,
    F15,
]
project_function_names = [
    "spring_design",
    "three_bar_truss",
    "cantilever_beam_design",
    "welded_beam_design",
    "gear_train_design",
    "pressure_vessel_optimization",
    "speed_reducer_optimization",
    "I_beam_vertical_deflection_design",
    "tubular_column_design",
]

algorithm_names = [
    "QPSO",
    "AQPSO",
    "PSO",
    "APSO",
    "DE",
    "ADE",
    "EO",
    "AEO",
    # "SOA",
    # "ASOA",
]

base_func_test_data = np.array(
    [
        base_func_data_QPSO,
        base_func_data_AQPSO,
        base_func_data_PSO,
        base_func_data_APSO,
        base_func_data_DE,
        base_func_data_ADE,
        base_func_data_EO,
        base_func_data_AEO,
        # base_func_data_SOA,
        # base_func_data_ASOA,
    ]
)

base_func_test_curve = [
    base_func_curve_QPSO,
    base_func_curve_AQPSO,
    base_func_curve_PSO,
    base_func_curve_APSO,
    base_func_curve_DE,
    base_func_curve_ADE,
    base_func_curve_EO,
    base_func_curve_AEO,
]

project_func_test_data = np.array(
    [
        project_func_data_QPSO,
        project_func_data_AQPSO,
        project_func_data_PSO,
        project_func_data_APSO,
        project_func_data_DE,
        project_func_data_ADE,
        project_func_data_EO,
        project_func_data_AEO,
        # project_func_data_SOA,
        # project_func_data_ASOA,
    ]
)

base_func_H = np.array(
    [
        base_func_data_AQPSO_H,
        base_func_data_APSO_H,
        base_func_data_ADE_H,
        base_func_data_AEO_H,
    ]
)


def base_median_best_worst_std():
    for i in range(len(algorithm_names)):
        print(
            f"{algorithm_names[i]}: median:\n",
            np.median(base_func_test_data[i], axis=0),
        )
        print(f"{algorithm_names[i]}: best:\n", np.min(base_func_test_data[i], axis=0))
        print(f"{algorithm_names[i]}: worst:\n", np.max(base_func_test_data[i], axis=0))
        print(f"{algorithm_names[i]}: std:\n", np.std(base_func_test_data[i], axis=0))
        print("\n")


def project_median_best_worst_std():
    for i in range(len(algorithm_names)):
        data = project_func_test_data[i][:, np.array([0, 1, 2, 3, 4, 5, 6, 7, 8])]
        print(f"{algorithm_names[i]}: median:\n", np.median(data, axis=0))
        print(f"{algorithm_names[i]}: best:\n", np.min(data, axis=0))
        print(f"{algorithm_names[i]}: worst:\n", np.max(data, axis=0))
        print(f"{algorithm_names[i]}: std:\n", np.std(data, axis=0))
        print("\n")


# 定义绘制箱线图的函数
def plot_boxplot(data, title, x_labels, y_labels, save_path):
    # 创建箱体并设置样式
    fig, ax = plt.subplots()  # 创建一个图形及子图
    boxprops = dict(color="blue")  # 定义箱子的样式：边框颜色为蓝色，无填充
    medianprops = dict(
        color="red", linewidth=1
    )  # 定义中位数线的样式：颜色为红色，线宽为1
    whiskerprops = dict(
        color="black", linewidth=1.5, linestyle="--"
    )  # 定义须的样式：颜色为绿色，线宽为1.5，虚线
    flierprops = dict(
        marker="+", markerfacecolor="red", markeredgecolor="red", markersize=8
    )  # 定义异常值的样式

    # 绘制箱型图
    ax.boxplot(
        data,
        vert=True,
        patch_artist=False,  # 移除填充
        boxprops=boxprops,
        medianprops=medianprops,
        whiskerprops=whiskerprops,
        flierprops=flierprops,
    )

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置全局字体为微软雅黑

    # 添加标签
    ax.set_title(title, fontsize=16)  # 设置标题及字体大小
    ax.set_ylabel(y_labels, fontsize=12)  # 设置 Y 轴标签及字体大小
    ax.set_xticklabels(
        x_labels, rotation=45, fontsize=10
    )  # 更改 X 轴标签，并旋转 45 度
    ax.grid(
        True, linestyle="-", linewidth=0.5, alpha=0.5
    )  # 显示网格线，样式为实线，线宽为0.5，透明度为0.5
    ax.set_yscale("log")
    # 保存图像
    # 将标题转换为文件名
    os.makedirs(save_path, exist_ok=True)
    filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
    plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")

    # 显示图形并继续执行代码
    plt.show(block=False)

    # 设置计时器在5秒后关闭窗口
    plt.pause(5)
    plt.close()


def plot_all_track_map(algorithm=None, F=None):
    def plot_track_map(
        func,
        all_points_1,
        track_1,
        all_points_2,
        track_2,
        lb,
        ub,
        title,
        resolution=250,
    ):
        x = np.linspace(lb[0], ub[0], resolution)
        y = np.linspace(lb[1], ub[1], resolution)
        z = []
        for i in x:
            for j in y:
                z.append(func(np.array([i, j])))
        z = np.array(z).reshape((resolution, resolution))

        plt.figure(figsize=(10, 10))

        # 绘制等高线
        plt.contour(x, y, z, levels=75, cmap="viridis")

        # 绘制所有点（在等高线之上）
        all_points_1 = np.array(all_points_1)
        plt.scatter(
            all_points_1[:, 0],
            all_points_1[:, 1],
            color="black",
            label="Original Points",
            zorder=2,
        )
        all_points_2 = np.array(all_points_2)
        plt.scatter(
            all_points_2[:, 0],
            all_points_2[:, 1],
            color="red",
            label="Adaptive Points",
            zorder=2,
        )

        # # 绘制轨迹（在等高线之上）
        # track_1 = np.array(track_1)
        # plt.plot(
        #     track_1[:, 0],
        #     track_1[:, 1],
        #     color="red",
        #     linewidth=2,
        #     label="Original Track",
        #     zorder=10,
        # )
        # # 绘制轨迹（在等高线之上）
        # track_2 = np.array(track_2)
        # plt.plot(
        #     track_2[:, 0],
        #     track_2[:, 1],
        #     color="red",
        #     linewidth=2,
        #     label="Adaptive Track",
        #     zorder=10,
        #     linestyle="--",
        # )

        # 添加标题和标签
        plt.title(title, fontsize=32)
        plt.legend(prop={"size": 20})
        plt.tick_params(axis="both", which="major", labelsize=20)

        save_path = "./figure/"
        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=1280, bbox_inches="tight")
        plt.show()

    def special_case(algorithm, F):
        func_index = F - 1
        ag_name = [QPSO, AQPSO, PSO, APSO, DE, ADE, EO, AEO]
        result = []
        for i in range(2):
            algorithm_1 = ag_name[2 * algorithm + i - 2]
            algorithm_1 = algorithm_1(
                *get_parameter(function_names[func_index], algorithm_1, dim=2)
            )
            result.append(algorithm_1.optimize()[-1])
        plot_track_map(
            function_names[func_index],
            result[0][0],
            result[0][1],
            result[1][0],
            result[1][1],
            get_lb_ub_dim(function_names[func_index], dim=2)[0],
            get_lb_ub_dim(function_names[func_index], dim=2)[1],
            f"F{func_index+1} {algorithm_names[(algorithm-1)*2]} track",
        )

    if F == None:
        for func_index in range(len(function_names)):
            for algorithm_index in range(len(algorithm_names) // 2):
                special_case(algorithm_index + 1, func_index + 1)
    else:
        special_case(algorithm, F)


def base_box():
    for func_index in range(len(function_names[:-4])):
        func_data = []
        for algorithm_index in range(len(algorithm_names)):
            algorithm_data = []
            for proccessing in range(100):
                algorithm_data.append(
                    base_func_test_data[algorithm_index][proccessing][func_index]
                )
            func_data.append(algorithm_data)
        plot_boxplot(
            func_data,
            f"F{func_index+1} boxplot",
            algorithm_names,
            "fitness",
            "./figure/",
        )


def project_box():
    for func_index in range(len(project_function_names)):
        func_data = []
        for algorithm_index in range(len(algorithm_names)):
            algorithm_data = []
            for proccessing in range(100):
                algorithm_data.append(
                    project_func_test_data[algorithm_index][proccessing][func_index]
                )
            func_data.append(algorithm_data)
        plot_boxplot(
            func_data,
            f"{project_function_names[func_index]} boxplot",
            algorithm_names,
            "value",
            "./figure/",
        )


def plot_all_optimization_curve(F=None):
    def plot_best(curve, title, save_path):
        color_list = ["red", "cyan", "green", "black"]
        for i in range(len(curve)):
            if i % 2 == 0:
                plt.plot(curve[i], linestyle="-", color=color_list[int(i / 2)])
            else:
                plt.plot(curve[i], linestyle="--", color=color_list[int(i / 2)])
        if np.min(curve) > 0:
            plt.yscale("log")  # 设置纵轴为对数尺度
        plt.xlabel("Iteration", fontsize=16)
        plt.ylabel("Fitness", fontsize=16)
        plt.title(title, fontsize=16)

        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")

        plt.show()

    if F == None:
        for F in range(len(function_names)):
            if F > 10:
                return
            curve_list = []
            for ag_index in range(len(algorithm_names)):
                curve_list.append(base_func_test_curve[ag_index][F])
            plot_best(
                title=f"F{F+1} optimization curve",
                save_path="./figure/",
                curve=curve_list,
            )
    else:
        curve_list = []
        for ag_index in range(len(algorithm_names)):
            curve_list.append(base_func_test_curve[ag_index][F - 1])
        plot_best(
            title=f"F{F} optimization curve", save_path="./figure/", curve=curve_list
        )


def plot_all_function_3D(F=None):
    def plot_function_3D(func, lb, ub, title, resolution=100):
        x = np.linspace(lb[0], ub[0], resolution)
        y = np.linspace(lb[1], ub[1], resolution)
        z = np.zeros((resolution, resolution))
        for i in range(resolution):
            for j in range(resolution):
                z[i, j] = func(np.array([x[i], y[j]]))

        fig = plt.figure(figsize=(5, 5))
        ax = fig.add_subplot(111, projection="3d")

        # 绘制3D曲面
        X, Y = np.meshgrid(x, y)
        ax.plot_surface(
            X, Y, z, cmap="viridis", alpha=0.8, rstride=1, cstride=1, edgecolor="none"
        )

        # 添加标题
        ax.set_title(title, fontsize=32)

        # # 设置刻度线但不显示刻度值
        # ax.xaxis.set_major_formatter(plt.NullFormatter())
        # ax.yaxis.set_major_formatter(plt.NullFormatter())
        # ax.zaxis.set_major_formatter(plt.NullFormatter())

        # # 隐藏刻度线
        # ax.xaxis.set_ticks([])
        # ax.yaxis.set_ticks([])
        # ax.zaxis.set_ticks([])

        save_path = "./figure/"
        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")
        plt.show()

    if F == None:
        for func_index in range(len(function_names)):
            plot_function_3D(
                function_names[func_index],
                get_lb_ub_dim(function_names[func_index], dim=2)[0],
                get_lb_ub_dim(function_names[func_index], dim=2)[1],
                f"F{func_index+1} 3D",
            )
    else:
        plot_function_3D(
            function_names[F - 1],
            get_lb_ub_dim(function_names[F - 1], dim=2)[0],
            get_lb_ub_dim(function_names[F - 1], dim=2)[1],
            f"F{F} 3D",
        )


def plot_H():
    x = []
    for i in range(100):
        if i == 0:
            x.append(1)
        else:
            x.append(int(5 * i))
    x_1 = []
    for i in range(11):
        if i == 0:
            x_1.append(1)
        else:
            x_1.append(int(50 * i))
    for i in range(len(base_func_H[0])):
        for j in range(len(base_func_H)):
            plt.plot(x, base_func_H[j][i])
            plt.yscale("log")  # 设置 y 轴为对数尺度
            plt.xticks(x_1)  # 自定义刻度位置
            plt.title(f"F{i+1} {algorithm_names[j*2+1]}", fontsize=32)
            title = f"F{i+1} {algorithm_names[j*2+1]} H"
            save_path = "./figure/"
            os.makedirs(save_path, exist_ok=True)
            filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
            plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")

            plt.show()


if "__main__" == __name__:
    # 可调用的函数
    # base_median_best_worst_std()
    # base_box()
    # plot_all_track_map()
    # plot_all_optimization_curve()
    # plot_all_function_3D(F=15)

    # project_median_best_worst_std()
    # project_box()

    plot_H()
