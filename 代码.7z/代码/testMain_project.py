from EA_toolbox import *
import numpy as np
from algorithms import *
import time
import multiprocessing

project_function_names = [
    spring_design,
    three_bar_truss,
    cantilever_beam_design,
    welded_beam_design,
    gear_train_design,
    pressure_vessel_optimization,
    speed_reducer_optimization,
    I_beam_vertical_deflection_design,
    tubular_column_design,
]


def get_parameter(func, algorithm_name, dim=100):
    size = 50
    iter_num = 100
    lb, ub, dim = get_lb_ub_dim(func, dim)
    is_print = False
    init_function = random_init
    if algorithm_name == QPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 0.6)
    if algorithm_name == AQPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 10)
    if algorithm_name == EO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 2, 1)
    if algorithm_name == AEO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 10)
    if algorithm_name == PSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 0.7, 2, 2)
    if algorithm_name == APSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 10)
    if algorithm_name == DE:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 0.5, 0.9)
    if algorithm_name == ADE:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 10)
    # if algorithm_name == SOA:
    #     return (func, init_function, dim, size, iter_num, lb, ub, is_print, 2)
    # if algorithm_name == ASOA:
    #     return (func, init_function, dim, size, iter_num, lb, ub, is_print, 5)


def one_poccessing(result_list_diff_poccessing, algorithm_name, function_names):
    result_in_one_poccessing = []
    for func in function_names:
        result_in_one_function = []
        algorithm = algorithm_name(*get_parameter(func, algorithm_name))
        result = algorithm.optimize()
        result_in_one_function.append(result[1])
        result_in_one_function.append(result[2])
        result_in_one_poccessing.append(result_in_one_function)

    result_list_diff_poccessing.append(result_in_one_poccessing)


num_test = 100
algorithm_name = AEO
# result_list_diff_poccessing = []
# one_poccessing(result_list_diff_poccessing, algorithm_name, project_function_names[8:9])

if __name__ == "__main__":
    start_time = time.time()
    print(
        "开始时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time)),
    )

    manager = multiprocessing.Manager()
    result_list_diff_poccessing = manager.list()  # 使用 Manager 的共享列表

    num_test_bench_list = split_into_chunks(num_test, chunk_size=20)

    sum_count_test = 0
    for num_test_bench in num_test_bench_list:
        print(f"轮次:{sum_count_test+1}/{num_test}")
        sum_count_test += num_test_bench

        processes = []
        for _ in range(num_test_bench):
            p = multiprocessing.Process(
                target=one_poccessing,
                args=(
                    result_list_diff_poccessing,
                    algorithm_name,
                    project_function_names,
                ),
            )
            processes.append(p)
            p.start()
        for p in processes:
            p.join()

    best_curve_list = []
    all_score = []
    for fun_index in range(len(project_function_names)):
        best_score = np.inf
        scores = []
        for poccessing_index in range(num_test):
            scores.append(result_list_diff_poccessing[poccessing_index][fun_index][0])
            if scores[-1] < best_score:
                best_score = result_list_diff_poccessing[poccessing_index][fun_index][0]
                best_curve = np.array(
                    result_list_diff_poccessing[poccessing_index][fun_index][1]
                )
        all_score.append(scores)
        best_curve_list.append(best_curve.copy().tolist())
    all_score = np.array(all_score).T
    print(all_score.tolist())
    print("\n\n")
    print(best_curve_list)
