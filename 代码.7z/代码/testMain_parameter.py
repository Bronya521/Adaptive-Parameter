from EA_toolbox import *
import numpy as np
from algorithms import *
import time
import multiprocessing

function_names = [
    Sphere,
    Rosenbrock,
    Schwefel_222,
    Schwefel_12,
    Schwefel_221,
    Schwefel_226,
    Rastrigin,
    Ackley,
    Griewank,
    Penalized1,
    Penalized2,
    F12,
    F13,
    F14,
    F15,
]


def get_parameter(func, H, dim=100):
    size = 100
    iter_num = 500
    lb, ub, dim = get_lb_ub_dim(func, dim)
    if dim != 100:
        size = 50
        iter_num = 200
    is_print = False
    init_function = random_init

    return (func, init_function, dim, size, iter_num, lb, ub, is_print, H)


def one_poccessing(result_list_diff_poccessing, algorithm_name, func):
    result_in_one_poccessing = []
    for i in range(100):
        if i == 0:
            H = 1
        else:
            H = int(5 * i)

        algorithm = algorithm_name(*get_parameter(func, H))
        result = algorithm.optimize()
        result_in_one_poccessing.append(result[1])
    result_list_diff_poccessing.append(result_in_one_poccessing)


num_test = 100
algorithm_name = AEO

# result_list_diff_poccessing = []
# one_poccessing(result_list_diff_poccessing, algorithm_name, function_names[7:8])

if __name__ == "__main__":
    start_time = time.time()
    print(
        "开始时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time)),
    )

    manager = multiprocessing.Manager()
    num_test_bench_list = split_into_chunks(num_test, chunk_size=20)

    result = []
    for func_idnex in range(len(function_names)):
        sum_count_test = 0
        func = function_names[func_idnex]
        result_list_diff_poccessing = manager.list()  # 使用 Manager 的共享列表
        for num_test_bench in num_test_bench_list:
            print(f"F{func_idnex+1} 轮次:{sum_count_test+1}/{num_test}")
            sum_count_test += num_test_bench

            processes = []
            for _ in range(num_test_bench):
                p = multiprocessing.Process(
                    target=one_poccessing,
                    args=(result_list_diff_poccessing, algorithm_name, func),
                )
                processes.append(p)
                p.start()
            for p in processes:
                p.join()

        result_list_diff_poccessing = np.array(result_list_diff_poccessing)
        result.append(np.median(result_list_diff_poccessing, axis=0).tolist())
        if func_idnex != len(function_names) - 1:
            time.sleep(60 * 3)
    print(result)
